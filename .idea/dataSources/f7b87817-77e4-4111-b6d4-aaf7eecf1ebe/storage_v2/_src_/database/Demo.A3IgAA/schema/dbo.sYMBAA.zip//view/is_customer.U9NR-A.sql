create view is_customer
as
select 姓名name
from customer
where 顾客编号customid=2
go


create view ViewExam
as
select name ViewExam1,address ViewExam2
from Exam
go


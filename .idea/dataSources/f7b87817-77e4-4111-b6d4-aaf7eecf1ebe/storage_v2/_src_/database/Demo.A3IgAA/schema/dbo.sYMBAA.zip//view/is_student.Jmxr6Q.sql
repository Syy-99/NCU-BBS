create view is_student 
as
select Name
from student
where Score>500
go

